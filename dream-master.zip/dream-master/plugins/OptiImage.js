import Vue from 'vue'
import OptiImage from 'opti-image'
Vue.use(OptiImage)
