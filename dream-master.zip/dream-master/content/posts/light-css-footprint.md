---
title: Amazon Linux2
subtitle: Amazon Linux2
category:
  - AWS
author: DP
date: 2019-10-18T17:30:16.858Z
featureImage: /uploads/amazon-linux2.jpg
---
ITテクノロジーは、ビジネスのためにグローバルに多くのドアを開きました。

この変革を利用する準備ができていますか?

成長するプレゼンスを作成しましょう！！
