<template>
  <div class="post-sidebar box">
    Sidear Here
  </div>
</template>
<script>
export default {
  name: 'PostSidebar'
}
</script>
