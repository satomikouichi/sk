<template functional>
  <a
    role="button"
    class="navbar-burger"
    aria-label="menu"
    aria-expanded="false"
    @click="listeners.click"
  >
    <span aria-hidden="true"></span>
    <span aria-hidden="true"></span>
    <span aria-hidden="true"></span>
  </a>
</template>
