import copyStaticToDist from '../build/copy-static-to-dist'

export default () => {
  copyStaticToDist()
}
