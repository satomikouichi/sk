export default ['assets/scss/styles.scss']
