export default [
  '~/plugins/Globals',
  '~/plugins/OptiImage',
  '~/plugins/Disqus',
  '~/plugins/EventBus',
  '~/plugins/Components'
]
