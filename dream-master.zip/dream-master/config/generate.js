export const routeMap = {
  '': 'posts/*.md',
  '/categories': 'categories/*.md'
}

export const otherRoutes = []
